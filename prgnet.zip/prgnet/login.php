<?php
 session_start();
 require 'config.php';
 
 $_SESSION['clogin'] = '';
 
 
 if(isset($_POST['email']) && !empty($_POST['email'])   )
 {
 $email = $_POST['email'];
 $senha = $_POST['senha'];
   
    $sql= "SELECT * FROM cad WHERE email = :email AND senha = MD5(:senha)";
    $sql=$pdo->prepare($sql);
    $sql->bindValue(":email", $email);
    $sql->bindValue(":senha", $senha);
     $sql->execute();
 
   if($sql->rowCount()>0){
       $sql=  $sql -> fetch();
       $id = $sql['id'];
       $ip = $_SERVER['REMOTE_ADDR'];
 
         $_SESSION['clogin'] = $id; 
    
       $sql= "UPDATE usuarios SET ip = :ip WHERE id = :id";
       $sql = $pdo->prepare($sql);
       $sql->bindValue(":ip",$ip);
       $sql->bindValue(":id",$id);
       $sql->execute();
 
       header("location: index.php");
       exit;
   }
 }
 ?>
<!DOCTYPE html>
    <meta charset="utf-8" />
    <title></title>
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1"/>
    <link rel="stylesheet" href="login.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="signin.css" rel="stylesheet">

</head>
<body>
    <header>
        <div class="container">
        </div>
    </header>
<main class="form-signin">

    <section class="container main">
        <form method="POST" >

        <h2 style="color: #3569d8; text-align: center; ">Login</h2> </br>
<div class="form-floating">
          <input type="email" name="email" class="form-control"  placeholder="name@example.com">
          <label for="floatingInput">Email </label>
</div>
<div class="form-floating">
         <input type="password" class="form-control" name="senha" placeholder="Password">
         <label for="floatingPassword">Password</label>
</div>
<div style="text-align: center; " >            
<input class="W-100 btn btn-lg btn-primary" type="submit" value="login" /> </br>
            <p class="mt-5 mb-3 text-muted">&copy; 2021–2022</p>
        </form>
    </section>
    </main>
</body>
</html>