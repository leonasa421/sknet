<div class="content">
      <div class="container-fluid">
          <div class="col-lg-9">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title"> O Cliente </h5>
                <p class="card-text">
				<?php
require 'config.php';


if (isset($_GET [trim("submit")])) {
    $busca = $_GET [trim("search")];
	$sth = $pdo->prepare("SELECT * FROM `sknet` WHERE codico = '$busca'");

	$sth->setfetchMode(PDO:: FETCH_OBJ);
	$sth -> execute();

	if($row = $sth->fetch())
	{
		?>
		<br><br><br>
		<table>

<style>

    b{
    color: blue;
    font-style: normal ;
    font-size: 20px;
    }
</style>
                <b>cliente: </b> <?=$row->cliente;?>
                <b>cep: </b><?=$row->cep;?></td>
                <b>endereco: </b><?=$row->endereco;?></td>
                <b>divida: </b><?=$row->divida;?>R$</td>
				<b>cpf: </b> <?= $row->cpf;?></td>
				<b>Complemento: </b><?=$row->complemento;?></td> 
		</table>
<?php 
	}
		
		
		else{
			echo "O cliente não possue cadastro na base de dados";
		}


}

?>               
                </p>
              </div>
            </div>
            </div>
          </div>