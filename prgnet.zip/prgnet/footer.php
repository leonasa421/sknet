</div>
      </div>
      <form method="$_GET">
<input  class= "form-control form-control-sidebar"  placeholder="Pesquisar" type="text" name="search">
<br>
<input  class="nav-link active" type="submit" name="submit" value="Buscar" >
</form>
<!-- AREA DE TESTES 

      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <li class="nav-item menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Contole
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
              <a href="addanuncio.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Procurar cliente</p>
                </a>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
    </div>
-->
  </aside>
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          <h1 class="m-0">Controle</h1>
        </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="login.php">login</a></li>
              <li class="breadcrumb-item active"><a href="sair.php"> sair</a>  </li>
            </ol>
          </div>
        </div>
      </div>
    </div>
     <?php
require 'corpo.php';
?>
<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>